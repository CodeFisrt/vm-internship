arr = [1,2,3,4,5,6];
arr1 = ["Vaishnavi","Muskan","Prerna","Ram","Sham"];
arr2 = ["Vaishnavi","Muskan","Prerna",3,4,5,6];
//
    employees=  [
      {
        "id": 1,
        "name": "John Doe",
        "designation": "Software Engineer",
        "department": "IT",
        "email": "john.doe@example.com",
        "salary": 60000,
        "joiningDate": "2022-05-10"
      },
      {
        "id": 2,
        "name": "Jane Smith",
        "designation": "Project Manager",
        "department": "Management",
        "email": "jane.smith@example.com",
        "salary": 90000,
        "joiningDate": "2021-08-15"
      },
      {
        "id": 3,
        "name": "Samuel Green",
        "designation": "Business Analyst",
        "department": "Business",
        "email": "samuel.green@example.com",
        "salary": 70000,
        "joiningDate": "2020-02-20"
      },
      {
        "id": 4,
        "name": "Emily Johnson",
        "designation": "UX Designer",
        "department": "Design",
        "email": "emily.johnson@example.com",
        "salary": 55000,
        "joiningDate": "2023-01-12"
      }
    ]
  console.log(employees);
  //push ==> add one element
  arr.push("Nitin");
  console.log(arr);
  //[1,2,3,4,5,6,7]
  //pop
  arr.pop();
  console.log(arr);
  //shift
  //unshift
  //concat
  //slice
  //splice
  //foreact
  //map
  //reduce
  //filter
  //find

