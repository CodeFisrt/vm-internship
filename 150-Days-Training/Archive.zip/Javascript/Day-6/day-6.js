//push
array = [1,2,3,4,5];
// [2,3,4,5,6]
array1 = [6,7,8,9,10];


// array.push(6);

// console.log(array);
//1,2,3,4,5,6 last element
// array.pop();

// console.log(array);
//1,2,3,4,5 last element

// array.shift();
// console.log(array)

// array.unshift(0);
// console.log(array)

// var concatResult = array.concat(array1);
// console.log(concatResult)

// console.log(array.slice(1,4))

//push(6)
//123456
//shift()


array.forEach(element => {
    // debugger;
    console.log(element+1);
});

// let newResult = array.map(x=>x+1);
// console.log(newResult);
// console.log(array)

// let filtered = array.filter(x => x > 2);  
// console.log(filtered);

// let sum = array.reduce((total, current) => total + current, 0);
// console.log(sum)