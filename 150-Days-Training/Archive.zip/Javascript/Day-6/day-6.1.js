// obj = {
//     key:value
// }
// let target = { a: 1,name:'gk' };
// let source = { b: 2, c: 3 };

// console.log(Object.assign(target,source))
 
// console.log(Object.keys(target))

//block
//globel
let x = 10;
if(true){
    let x = 20
    // console.log(x)
    //
}

// console.log(x)
//

const y = 10;
if(true){
    const y = 20
    console.log(y)
    //
}

const user = {
  name: "John Doe",
  age: 30,
  addresses: [
    { type: "home", city: "New York", zip: "10001" },
    { type: "work", city: "San Francisco", zip: "94101" }
  ],
  hobbies: ["reading", "coding", "hiking"],
}


//

const user1 = {
  name: "John Doe",
  age: 30,
  addresses: [
    { type: "home", city: "New York", zip: "10001" },
    { type: "work", city: "San Francisco", zip: "94101" },
    
  ],
  hobbies: ["reading", "coding", "hiking"],
};
// getNewdata(){

//     return(user1.addresses.)
// }
addneobj = { type: "personal", city: "Pune", zip: "94101123456" }

console.log(user1.addresses.addneobj)

array = [1,2,3,4] 

//45
//30min js/project/logic
//15 intro,ui,

//[2,3,4,5]
//for
//map
//js 3-5 topic
//angular