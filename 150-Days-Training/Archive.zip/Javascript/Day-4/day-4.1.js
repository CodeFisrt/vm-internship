// events
// onclick
// mousehouver
// minimum 5 evenets
document.getElementById('hoverId').addEventListener("mouseover",function(){
    this.style.backgroundColor = "red"
})