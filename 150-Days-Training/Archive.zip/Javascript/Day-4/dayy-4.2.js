//key value
localStorage.setItem('Name','Code');
 var showname = localStorage.getItem('Name');
 console.log(showname)

 sessionStorage.setItem('Name','Gorakh');