var x = 10;
var y = 5;

// console.log(x>5 &&  y< 10 )
//

// console.log(x>5 ||  y< 10 );
// if one condition is true then output will be true

var isVote = true;
// console.log(!isVote);
// false
 var age = 17;
 var result = (age >= 18 ? 'Yes you can vote':'Cannot vote');
//  console.log(result)

//  if(age >=18){
//     console.log("you are elogible fo voting");
//  }else{
//     console.log("you are Not elogible fo voting");

//  }

 //switch
 var day = 40;

//  switch(day){
//     case 1: 
//     console.log("Monday");
//     break;
//     case 2: 
//     console.log("Tuesday");
//     break;
//     case 3: 
//     console.log("Wensday");
//     break;
//     case 4: 
//     console.log("Thersday");
//     break;
//     case 5: 
//     console.log("Friday");
//     break;
//     case 6: 
//     console.log("Saturday");
//     break;
//     case 7: 
//     console.log("Sunday");
//     break;
//     default:
//         console.log("Please enter correct value");
//  }
 //for loop

 //1,2,3,4
//  console.log("1")
//  console.log("2")
//  console.log("3")
//  console.log("4")
//  console.log("5")
//  console.log("6")
//  console.log("7")
//  console.log("8")
//  console.log("9")
//  console.log("10")
//  console.log("11")
//  console.log("12")
//  console.log("13")
for(var i = 1; i< 14 ; i++){
    //initilization condition incre/dec
    // matrix
    //table
    //fibonacci
    //even/odd
    //star pritings
    //
   //  console.log("The value is", i)
};
function add(event){
   console.log("test");
}
