var a = 10;
var b = 20;
console.log(a===b);

// false
// what is diff bet == and ===(value and datatype)
console.log(a>b);
//false
console.log(a<b);
console.log(a!=b);
// 

userAdge = 20;
