// variable

var username = 'Gorakh';
// console.log(username);
// alert(username)

// var name = expression
// let const

var adge = 32;
var educ = "ME Computer";

var username1 = "gk";

// var if = 'keyword'
// variable cannot use as keyword

// variable cannot start with num
// 1usename = 

// primitive  non primitive
 var num = 34;
// number
var collageName = "RGIT"
// string
var pass = true;
//boolean
var attendance = null
//null
var marks;
//undefined
var obj = {
    key:value
}
//object
var array = ['abac', 23,'codefirst',null];
//array