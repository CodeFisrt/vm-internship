//js oprator
//Arithmatic
//+,- ,* , /, % ++ , --

var a = 10;
var b= 20;
console.log("value of a",a,"value of b", b,"Addition of a and b is", a+b);
console.log("value of a",a,"value of b", b,"Sub of a and b is", a-b);
console.log("value of a",a,"value of b", b,"multiplications of a and b is", a*b);
console.log("value of a",a,"value of b", b,"Division of a and b is", b/a);
console.log("value of a",a,"value of b", b,"division of a and b is", a/b);
console.log("value of a"+a,"value of b", b,"modulus of a and b is", a%b);
console.log(++a);
console.log(--a);

console.log(2+'2');
// 2
// 22

console.log("2"+2);
//22

console.log(1+2+"3")
// 123
//33
console.log(3+"3"+3)
// 333

// alert(a+b)
 // assignmet
 var c = 30;
 console.log(c);
 c += 4
console.log(c);

//comparion oprators
var d = 50;
var e = '50';
console.log(d==e);
console.log(d===e);

// what is diffrence bet == and ===



